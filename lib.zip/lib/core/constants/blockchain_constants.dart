class BlockchainConstants {
  // ========== NETWORK CONFIGURATION ==========

  /// Polygon Mumbai Testnet (for development)
  static const String networkName = 'Polygon Mumbai';
  static const int chainId = 80001;

  /// RPC URL - Replace with your Alchemy/Infura URL
  /// Get free API key from: https://www.alchemy.com/
  static const String rpcUrl =
      'https://polygon-mumbai.g.alchemy.com/v2/YOUR_API_KEY';

  /// Alternative RPC URLs (fallback)
  static const List<String> fallbackRpcUrls = [
    'https://rpc-mumbai.maticvigil.com/',
    'https://matic-mumbai.chainstacklabs.com',
  ];

  /// Block Explorer
  static const String blockExplorerUrl = 'https://mumbai.polygonscan.com';

  // ========== SMART CONTRACT ==========

  /// FitnessBadge NFT Contract Address
  /// ⚠️ REPLACE THIS after deploying contract
  static const String contractAddress =
      '0x0000000000000000000000000000000000000000';

  /// Contract deployment transaction (for reference)
  static const String? deploymentTxHash = null;

  // ========== GAS SETTINGS ==========

  /// Gas limit for minting NFT
  static const int gasLimit = 300000;

  /// Max gas price (in Gwei)
  static const double maxGasPrice = 50.0;

  // ========== IPFS CONFIGURATION ==========

  /// IPFS Gateway URL
  static const String ipfsGateway = 'https://gateway.pinata.cloud/ipfs/';

  /// Pinata API (for uploading metadata)
  /// Get API key from: https://www.pinata.cloud/
  static const String pinataApiKey = 'YOUR_PINATA_API_KEY';
  static const String pinataSecretKey = 'YOUR_PINATA_SECRET_KEY';

  // ========== WALLET ==========

  /// WalletConnect Project ID
  /// Get from: https://cloud.walletconnect.com/
  static const String walletConnectProjectId = 'YOUR_WALLETCONNECT_PROJECT_ID';

  // ========== VALIDATION ==========

  /// Check if blockchain is configured
  static bool get isConfigured {
    return contractAddress != '0x0000000000000000000000000000000000000000' &&
        rpcUrl.contains('YOUR_API_KEY') == false;
  }

  /// Get block explorer URL for transaction
  static String getTxUrl(String txHash) {
    return '$blockExplorerUrl/tx/$txHash';
  }

  /// Get block explorer URL for address
  static String getAddressUrl(String address) {
    return '$blockExplorerUrl/address/$address';
  }

  /// Get block explorer URL for token
  static String getTokenUrl(String tokenId) {
    return '$blockExplorerUrl/token/$contractAddress?a=$tokenId';
  }

  /// Get IPFS URL
  static String getIpfsUrl(String hash) {
    return '$ipfsGateway$hash';
  }
}
