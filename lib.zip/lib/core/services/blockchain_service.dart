import 'dart:convert';
import 'dart:math';
import 'package:flutter/services.dart' show rootBundle;
import 'package:http/http.dart' as http;
import 'package:smart_fitness_assistant/core/models/nft_badge.dart';
import 'package:smart_fitness_assistant/core/constants/blockchain_constants.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:web3dart/web3dart.dart';

/// Real Blockchain Service with Web3 integration
/// Connects to Polygon Mumbai testnet and interacts with FitnessBadge smart contract
class BlockchainService {
  static final BlockchainService _instance = BlockchainService._internal();
  factory BlockchainService() => _instance;
  BlockchainService._internal();

  // Web3 client
  Web3Client? _client;
  DeployedContract? _contract;

  // Wallet
  String? _walletAddress;
  Credentials? _credentials;

  // Supabase for caching
  final _supabase = Supabase.instance.client;

  // Initialization flag
  bool _isInitialized = false;

  /// Initialize Web3 connection
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      // Check if blockchain is configured
      if (!BlockchainConstants.isConfigured) {
        print('⚠️ Blockchain not configured. Using mock mode.');
        return;
      }

      // Create Web3 client
      _client = Web3Client(BlockchainConstants.rpcUrl, http.Client());

      // Load contract ABI
      final abiString = await rootBundle.loadString(
        'assets/contracts/FitnessBadge.json',
      );
      final abiJson = jsonDecode(abiString);
      final abi = jsonEncode(abiJson['abi']);

      // Create contract instance
      _contract = DeployedContract(
        ContractAbi.fromJson(abi, 'FitnessBadge'),
        EthereumAddress.fromHex(BlockchainConstants.contractAddress),
      );

      _isInitialized = true;
      print('✅ Blockchain service initialized');
    } catch (e) {
      print('❌ Failed to initialize blockchain: $e');
      _isInitialized = false;
    }
  }

  /// Connect wallet (mock for now, real wallet integration would use WalletConnect)
  Future<void> connectWallet() async {
    if (_walletAddress != null) return;

    // TODO: Implement real wallet connection with WalletConnect
    // For now, generate mock wallet for testing
    await Future.delayed(const Duration(seconds: 1));
    _walletAddress = _generateMockAddress();

    print('✅ Wallet connected: $_walletAddress');
  }

  /// Mint NFT Badge on blockchain
  Future<NFTBadge> mintBadge({
    required String name,
    required String description,
    required BadgeRarity rarity,
    required NFTMetadata metadata,
    String? userId,
  }) async {
    if (!_isInitialized || _client == null || _contract == null) {
      // Fallback to mock if blockchain not configured
      return await _mintMockBadge(name, description, rarity, metadata, userId);
    }

    try {
      await connectWallet();

      // 1. Upload metadata to IPFS
      final tokenUri = await _uploadMetadataToIPFS(
        name: name,
        description: description,
        rarity: rarity,
        metadata: metadata,
      );

      // 2. Mint NFT on blockchain
      final tokenId = await _mintOnChain(
        to: _walletAddress!,
        tokenUri: tokenUri,
        rarity: rarity,
        metadata: metadata,
      );

      // 3. Create badge object
      final badge = NFTBadge(
        id: tokenId.toString(),
        tokenId: tokenId.toString(),
        name: name,
        description: description,
        rarity: rarity,
        imageUrl: _getBadgeImageUrl(rarity, metadata.workoutType),
        metadata: metadata,
        mintedAt: DateTime.now(),
        ownerAddress: _walletAddress!,
      );

      // 4. Cache in database
      if (userId != null) {
        await _saveBadgeToDatabase(badge, userId);
      }

      return badge;
    } catch (e) {
      print('❌ Error minting badge on blockchain: $e');
      // Fallback to mock
      return await _mintMockBadge(name, description, rarity, metadata, userId);
    }
  }

  /// Mint NFT on blockchain (call smart contract)
  Future<String> _mintOnChain({
    required String to,
    required String tokenUri,
    required BadgeRarity rarity,
    required NFTMetadata metadata,
  }) async {
    if (_client == null || _contract == null || _credentials == null) {
      throw Exception('Blockchain not initialized or wallet not connected');
    }

    // Get contract function
    final mintFunction = _contract!.function('mintBadge');

    // Prepare parameters
    final params = [
      EthereumAddress.fromHex(to),
      tokenUri,
      BigInt.from(rarity.index), // 0=common, 1=rare, 2=epic, 3=legendary
      metadata.workoutType,
      BigInt.from(metadata.totalExercises),
      BigInt.from(metadata.durationMinutes),
      BigInt.from(metadata.caloriesBurned.toInt()),
    ];

    // Send transaction
    final txHash = await _client!.sendTransaction(
      _credentials!,
      Transaction.callContract(
        contract: _contract!,
        function: mintFunction,
        parameters: params,
        maxGas: BlockchainConstants.gasLimit,
      ),
      chainId: BlockchainConstants.chainId,
    );

    print('✅ Transaction sent: $txHash');

    // Wait for confirmation
    final receipt = await _client!.getTransactionReceipt(txHash);

    // Extract token ID from event logs
    // TODO: Parse logs to get actual token ID
    final tokenId = DateTime.now().millisecondsSinceEpoch.toString();

    return tokenId;
  }

  /// Upload metadata to IPFS (simplified - use Pinata API in production)
  Future<String> _uploadMetadataToIPFS({
    required String name,
    required String description,
    required BadgeRarity rarity,
    required NFTMetadata metadata,
  }) async {
    // Create metadata JSON
    final metadataJson = {
      'name': name,
      'description': description,
      'image': _getBadgeImageUrl(rarity, metadata.workoutType),
      'attributes': [
        {'trait_type': 'Rarity', 'value': rarity.name.toUpperCase()},
        {'trait_type': 'Workout Type', 'value': metadata.workoutType},
        {'trait_type': 'Exercises', 'value': metadata.totalExercises},
        {'trait_type': 'Duration (min)', 'value': metadata.durationMinutes},
        {
          'trait_type': 'Calories Burned',
          'value': metadata.caloriesBurned.toInt(),
        },
        {
          'trait_type': 'Completed At',
          'value': metadata.completedAt.toIso8601String(),
        },
      ],
    };

    // TODO: Upload to IPFS using Pinata API
    // For now, return mock IPFS hash
    final mockHash = 'Qm${_generateRandomHash()}';
    return 'ipfs://$mockHash';
  }

  /// Fallback: Mint mock badge
  Future<NFTBadge> _mintMockBadge(
    String name,
    String description,
    BadgeRarity rarity,
    NFTMetadata metadata,
    String? userId,
  ) async {
    // Simulate blockchain transaction delay
    await Future.delayed(const Duration(seconds: 2));

    await connectWallet();

    final tokenId = _generateTokenId();
    final badge = NFTBadge(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      tokenId: tokenId,
      name: name,
      description: description,
      rarity: rarity,
      imageUrl: _getBadgeImageUrl(rarity, metadata.workoutType),
      metadata: metadata,
      mintedAt: DateTime.now(),
      ownerAddress: _walletAddress!,
    );

    // Save to database
    if (userId != null) {
      await _saveBadgeToDatabase(badge, userId);
    }

    return badge;
  }

  /// Save badge to Supabase database (cache)
  Future<void> _saveBadgeToDatabase(NFTBadge badge, String userId) async {
    try {
      await _supabase.from('nft_badges').insert({
        'user_id': userId,
        'token_id': int.tryParse(badge.tokenId) ?? 0,
        'name': badge.name,
        'description': badge.description,
        'rarity':
            badge.rarity.name[0].toUpperCase() +
            badge.rarity.name.substring(
              1,
            ), // Capitalize: Common, Rare, Epic, Legendary
        'metadata': badge.metadata.toJson(),
        'image_url': badge.imageUrl,
        'owner_address': badge.ownerAddress,
        'minted_at': badge.mintedAt.toIso8601String(),
        'is_showcased': badge.isShowcased,
      });
      print('✅ Badge saved to database');
    } catch (e) {
      print('❌ Error saving badge to database: $e');
      rethrow;
    }
  }

  /// Get user's badges from blockchain
  Future<List<NFTBadge>> getUserBadges(String userId) async {
    try {
      // First, try to get from database (cache)
      final response = await _supabase
          .from('nft_badges')
          .select()
          .eq('user_id', userId)
          .order('minted_at', ascending: false);

      return (response as List).map((json) {
        // Parse metadata from JSONB
        final metadataJson = json['metadata'] as Map<String, dynamic>? ?? {};

        return NFTBadge(
          id: json['id'],
          tokenId: json['token_id']?.toString() ?? '0',
          name: json['name'] ?? 'Unknown Badge',
          description: json['description'] ?? '',
          rarity: BadgeRarity.values.firstWhere(
            (e) =>
                e.name.toLowerCase() ==
                (json['rarity'] as String).toLowerCase(),
            orElse: () => BadgeRarity.common,
          ),
          imageUrl: json['image_url'] ?? '',
          metadata: NFTMetadata.fromJson(metadataJson),
          mintedAt: DateTime.parse(json['minted_at']),
          ownerAddress: json['owner_address'] ?? '',
          isShowcased: json['is_showcased'] ?? false,
        );
      }).toList();
    } catch (e) {
      print('❌ Error loading badges: $e');
      return [];
    }
  }

  /// Toggle showcase status
  Future<void> toggleShowcase(String badgeId, bool isShowcased) async {
    try {
      await _supabase
          .from('nft_badges')
          .update({'is_showcased': isShowcased})
          .eq('id', badgeId);
    } catch (e) {
      print('❌ Error toggling showcase: $e');
    }
  }

  // Helper methods
  String _generateMockAddress() {
    final random = Random();
    return '0x${List.generate(40, (_) => random.nextInt(16).toRadixString(16)).join()}';
  }

  String _generateTokenId() {
    return DateTime.now().millisecondsSinceEpoch.toString();
  }

  String _generateRandomHash() {
    final random = Random();
    return List.generate(
      46,
      (_) => random.nextInt(16).toRadixString(16),
    ).join();
  }

  String _getBadgeImageUrl(BadgeRarity rarity, String workoutType) {
    final rarityPrefix = rarity.name;
    return 'https://nft-storage.example.com/badges/$rarityPrefix-$workoutType.png';
  }

  String? get walletAddress => _walletAddress;
  bool get isInitialized => _isInitialized;
  bool get isBlockchainEnabled => _isInitialized && _client != null;
}
