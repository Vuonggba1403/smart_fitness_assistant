class NFTBadge {
  final String id;
  final String tokenId;
  final String name;
  final String description;
  final BadgeRarity rarity;
  final String imageUrl;
  final NFTMetadata metadata;
  final DateTime mintedAt;
  final String ownerAddress;
  final bool isShowcased;

  NFTBadge({
    required this.id,
    required this.tokenId,
    required this.name,
    required this.description,
    required this.rarity,
    required this.imageUrl,
    required this.metadata,
    required this.mintedAt,
    required this.ownerAddress,
    this.isShowcased = false,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'token_id': tokenId,
    'name': name,
    'description': description,
    'rarity': rarity.name,
    'image_url': imageUrl,
    'metadata': metadata.toJson(),
    'minted_at': mintedAt.toIso8601String(),
    'owner_address': ownerAddress,
    'is_showcased': isShowcased,
  };

  factory NFTBadge.fromJson(Map<String, dynamic> json) {
    // Parse rarity - handle both lowercase and capitalized
    final rarityStr = (json['rarity'] as String).toLowerCase();
    final rarity = BadgeRarity.values.firstWhere(
      (e) => e.name.toLowerCase() == rarityStr,
      orElse: () => BadgeRarity.common,
    );

    // Parse metadata - handle both Map and already parsed object
    final metadataJson = json['metadata'] is Map<String, dynamic>
        ? json['metadata'] as Map<String, dynamic>
        : <String, dynamic>{};

    return NFTBadge(
      id: json['id'] ?? '',
      tokenId: json['token_id']?.toString() ?? '0',
      name: json['name'] ?? 'Unknown Badge',
      description: json['description'] ?? '',
      rarity: rarity,
      imageUrl: json['image_url'] ?? '',
      metadata: NFTMetadata.fromJson(metadataJson),
      mintedAt: DateTime.parse(json['minted_at']),
      ownerAddress: json['owner_address'] ?? '',
      isShowcased: json['is_showcased'] ?? false,
    );
  }
}

class NFTMetadata {
  final String workoutType;
  final int totalExercises;
  final int durationMinutes;
  final double caloriesBurned;
  final DateTime completedAt;
  final Map<String, dynamic>? extraData;

  NFTMetadata({
    required this.workoutType,
    required this.totalExercises,
    required this.durationMinutes,
    required this.caloriesBurned,
    required this.completedAt,
    this.extraData,
  });

  Map<String, dynamic> toJson() => {
    'workout_type': workoutType,
    'total_exercises': totalExercises,
    'duration_minutes': durationMinutes,
    'calories_burned': caloriesBurned,
    'completed_at': completedAt.toIso8601String(),
    'extra_data': extraData,
  };

  factory NFTMetadata.fromJson(Map<String, dynamic> json) {
    return NFTMetadata(
      workoutType: json['workout_type'] ?? 'Unknown',
      totalExercises: json['total_exercises'] ?? 0,
      durationMinutes: json['duration_minutes'] ?? 0,
      caloriesBurned: (json['calories_burned'] as num?)?.toDouble() ?? 0.0,
      completedAt: json['completed_at'] != null
          ? DateTime.parse(json['completed_at'])
          : DateTime.now(),
      extraData: json['extra_data'] as Map<String, dynamic>?,
    );
  }
}

enum BadgeRarity {
  common, // Workout bình thường
  rare, // 7 day streak
  epic, // 30 day streak
  legendary, // 1000 exercises
}

class Achievement {
  final String id;
  final String name;
  final String description;
  final AchievementType type;
  final int targetValue;
  final int currentValue;
  final BadgeRarity badgeRarity;
  final String badgeImageUrl;
  final bool isCompleted;
  final DateTime? completedAt;

  Achievement({
    required this.id,
    required this.name,
    required this.description,
    required this.type,
    required this.targetValue,
    required this.currentValue,
    required this.badgeRarity,
    required this.badgeImageUrl,
    this.isCompleted = false,
    this.completedAt,
  });

  double get progress => (currentValue / targetValue).clamp(0.0, 1.0);

  Achievement copyWith({
    int? currentValue,
    bool? isCompleted,
    DateTime? completedAt,
  }) => Achievement(
    id: id,
    name: name,
    description: description,
    type: type,
    targetValue: targetValue,
    currentValue: currentValue ?? this.currentValue,
    badgeRarity: badgeRarity,
    badgeImageUrl: badgeImageUrl,
    isCompleted: isCompleted ?? this.isCompleted,
    completedAt: completedAt ?? this.completedAt,
  );
}

enum AchievementType {
  totalWorkouts,
  totalExercises,
  streakDays,
  totalCalories,
  specificWorkoutType,
}
