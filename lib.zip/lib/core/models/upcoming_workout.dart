class UpcomingWorkout {
  final String categoryId;
  final String categoryName;
  final String imageUrl;
  final DateTime scheduledTime;
  final int totalExercises;
  final int completedExercises;
  final bool isNotificationEnabled;

  UpcomingWorkout({
    required this.categoryId,
    required this.categoryName,
    required this.imageUrl,
    required this.scheduledTime,
    required this.totalExercises,
    required this.completedExercises,
    this.isNotificationEnabled = false,
  });

  // ✅ Progress dựa trên số exercises đã hoàn thành
  double get progressPercent => totalExercises > 0
      ? (completedExercises / totalExercises).clamp(0.0, 1.0)
      : 0.0;

  bool get isCompleted => completedExercises >= totalExercises;
  bool get isInProgress =>
      completedExercises > 0 && completedExercises < totalExercises;

  // ✅ FIX: Format thời gian relative to selectedDate
  String getFormattedTime({DateTime? referenceDate}) {
    final reference = referenceDate ?? DateTime.now();
    final referenceDay = DateTime(
      reference.year,
      reference.month,
      reference.day,
    );
    final scheduledDay = DateTime(
      scheduledTime.year,
      scheduledTime.month,
      scheduledTime.day,
    );

    final hour = scheduledTime.hour.toString().padLeft(2, '0');
    final minute = scheduledTime.minute.toString().padLeft(2, '0');

    // Check if same day
    if (scheduledDay == referenceDay) {
      return 'Hôm nay, $hour:$minute';
    }

    // Check if tomorrow
    if (scheduledDay == referenceDay.add(const Duration(days: 1))) {
      return 'Ngày mai, $hour:$minute';
    }

    // Otherwise show date
    final day = scheduledTime.day.toString().padLeft(2, '0');
    final month = scheduledTime.month.toString().padLeft(2, '0');
    return '$day/$month, $hour:$minute';
  }

  // ✅ ADD: Backward compatibility
  String get formattedTime => getFormattedTime();

  // ✅ FIX: copyWith hỗ trợ cập nhật scheduledTime
  UpcomingWorkout copyWith({
    String? categoryId,
    String? categoryName,
    String? imageUrl,
    DateTime? scheduledTime,
    int? totalExercises,
    int? completedExercises,
    bool? isNotificationEnabled,
  }) {
    return UpcomingWorkout(
      categoryId: categoryId ?? this.categoryId,
      categoryName: categoryName ?? this.categoryName,
      imageUrl: imageUrl ?? this.imageUrl,
      scheduledTime: scheduledTime ?? this.scheduledTime,
      totalExercises: totalExercises ?? this.totalExercises,
      completedExercises: completedExercises ?? this.completedExercises,
      isNotificationEnabled:
          isNotificationEnabled ?? this.isNotificationEnabled,
    );
  }
}
