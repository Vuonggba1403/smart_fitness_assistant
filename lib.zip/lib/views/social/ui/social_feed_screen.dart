import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get_utils/src/extensions/internacionalization.dart';
import 'package:image_picker/image_picker.dart';
import 'package:smart_fitness_assistant/core/functions/custom_appbar.dart';
import 'package:smart_fitness_assistant/core/functions/color_extension.dart';
import 'package:smart_fitness_assistant/core/models/exercise_category.dart';
import 'package:smart_fitness_assistant/locale/locale_key.dart';
import 'package:smart_fitness_assistant/views/social/logic/cubit/social_feed_cubit.dart';
import 'package:smart_fitness_assistant/views/social/ui/widgets/social_post_card.dart';
import 'package:smart_fitness_assistant/views/social/ui/widgets/social_post_creation_card.dart';
import 'package:smart_fitness_assistant/views/social/ui/widgets/social_create_post_dialog.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SocialFeedScreen extends StatefulWidget {
  const SocialFeedScreen({super.key});

  @override
  State<SocialFeedScreen> createState() => _SocialFeedScreenState();
}

class _SocialFeedScreenState extends State<SocialFeedScreen> {
  final TextEditingController _captionController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final _supabase = Supabase.instance.client;
  List<ExerciseCategory>? _categories;

  @override
  void initState() {
    super.initState();
    _loadCategories();
    context.read<SocialFeedCubit>().loadFeed();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _captionController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      context.read<SocialFeedCubit>().loadMorePosts();
    }
  }

  Future<void> _loadCategories() async {
    final res = await _supabase.from('exercise_categories').select();
    setState(() {
      _categories = res.map((e) => ExerciseCategory.fromJson(e)).toList();
    });
  }

  /// PICK IMAGE
  Future<void> _pickImage(ImageSource source) async {
    try {
      final picker = ImagePicker();
      final img = await picker.pickImage(source: source);
      if (img != null) {
        // ✅ Update Cubit state instead of local state
        context.read<SocialFeedCubit>().setSelectedImage(File(img.path));
      }
    } catch (e) {
      print('❌ pickImage error: $e');
    }
  }

  /// DIALOG SELECT IMAGE SOURCE
  void _showImageSourceDialog() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.camera_alt, color: TColor.primaryColor1),
              title: Text(LocaleKey.postImg.tr),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: Icon(Icons.photo_library, color: TColor.primaryColor1),
              title: Text(LocaleKey.choiceImg.tr),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  /// POST CONTENT through Cubit
  Future<void> _postContent() async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) return;

    // ✅ Get state from Cubit
    final cubitState = context.read<SocialFeedCubit>().state;
    if (cubitState is! SocialFeedLoaded) return;

    String? imageUrl;

    try {
      if (cubitState.selectedImage != null) {
        final fileName =
            'posts/$userId/${DateTime.now().millisecondsSinceEpoch}.jpg';

        // 1️⃣ UPLOAD FILE LÊN STORAGE BUCKET
        await _supabase.storage
            .from('fitness_posts') // Tên bucket
            .upload(fileName, cubitState.selectedImage!); // Upload file thực

        // 2️⃣ LẤY PUBLIC URL
        imageUrl = _supabase.storage
            .from('fitness_posts')
            .getPublicUrl(fileName); // Lấy URL công khai: https://...
      }

      // ignore: use_build_context_synchronously
      await context.read<SocialFeedCubit>().createPost(
        caption: _captionController.text,
        imageUrl: imageUrl,
        taggedCategoryId: cubitState.selectedCategory?.id,
        taggedCategoryName: cubitState.selectedCategory?.titleEx,
      );

      if (mounted) Navigator.pop(context);

      _captionController.clear();
    } catch (e) {
      print("❌ Error posting: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textColor = theme.textTheme.bodyMedium?.color;

    return Scaffold(
      appBar: CustomAppBar(
        title: LocaleKey.titleSocial.tr,
        showBackButton: false,
      ),
      backgroundColor: theme.scaffoldBackgroundColor,
      body: BlocBuilder<SocialFeedCubit, SocialFeedState>(
        builder: (context, state) {
          if (state is SocialFeedLoaded) {
            final posts = state.posts;

            return ListView(
              controller: _scrollController,
              padding: const EdgeInsets.all(12),
              children: [
                SocialPostCreationCard(
                  textColor: textColor,
                  theme: theme,
                  onTap: _showPostDialog,
                ),
                if (posts.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(50),
                    child: Center(
                      child: Text(
                        LocaleKey.noPost.tr,
                        style: TextStyle(color: textColor),
                      ),
                    ),
                  )
                else ...[
                  ...posts.map(
                    (post) => SocialPostCard(
                      post: post,
                      textColor: textColor,
                      theme: theme,
                      onLikeTap: () {
                        if (post.id != null && post.id!.isNotEmpty) {
                          context.read<SocialFeedCubit>().togglePostLike(
                            post.id!,
                          );
                        }
                      },
                    ),
                  ),
                  if (state.isLoadingMore)
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Center(
                        child: CircularProgressIndicator(
                          color: TColor.primaryColor1,
                        ),
                      ),
                    )
                  else if (!state.hasMore && posts.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Center(
                        child: Text(
                          LocaleKey.noMoreData.tr,
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                    ),
                ],
              ],
            );
          }

          return const SizedBox();
        },
      ),
    );
  }

  void _showPostDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => BlocBuilder<SocialFeedCubit, SocialFeedState>(
        builder: (bottomContext, state) {
          if (state is! SocialFeedLoaded) {
            return const SizedBox();
          }

          return SocialCreatePostDialog(
            captionController: _captionController,
            selectedImage: state.selectedImage,
            categories: _categories,
            selectedCategory: state.selectedCategory,
            onImagePickerTap: _showImageSourceDialog,
            onPostPressed: _postContent,
            onCategoryChanged: (c) {
              context.read<SocialFeedCubit>().setSelectedCategory(c);
            },
            onImageRemove: () {
              context.read<SocialFeedCubit>().clearSelectedImage();
            },
          );
        },
      ),
    );
  }
}
